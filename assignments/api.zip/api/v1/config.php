<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'bookfoxi_product');
define('DB_PASSWORD', 'product@2015');
define('DB_HOST', 'localhost');
define('DB_NAME', 'bookfoxi_products');
?>
